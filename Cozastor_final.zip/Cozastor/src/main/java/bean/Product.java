package bean;

	public class Product {
	    private int product_id;
	    private String name;
	    private int brand_id;
	    private String brandName;
	    private int price;
	    private String color;
	    private String specification;
	    private String image_url;
		public Product(int product_id, String name, int price) {
			super();
			this.product_id = product_id;
			this.name = name;
			this.price = price;
		}
		public Product() {
			// TODO Auto-generated constructor stub
		}
		public int getProduct_id() {
			return product_id;
		}
		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getBrand_id() {
			return brand_id;
		}
		public void setBrand_id(int brand_id) {
			this.brand_id = brand_id;
		}
		public String getBrandName() {
			return brandName;
		}
		public void setBrandName(String brandName) {
			this.brandName = brandName;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
		public String getSpecification() {
			return specification;
		}
		public void setSpecification(String specification) {
			this.specification = specification;
		}
		public String getImage_url() {
			return image_url;
		}
		public void setImage_url(String image_url) {
			this.image_url = image_url;
		}
	    
		
}